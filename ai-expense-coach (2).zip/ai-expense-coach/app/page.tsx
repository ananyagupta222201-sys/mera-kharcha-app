"use client"
import { useState, useEffect } from "react"

export default function Page() {
  const [input, setInput] = useState("")
  const [items, setItems] = useState<string[]>([])

  // PAGE KHULTE HI PURANA DATA LOAD
  useEffect(() => {
    const saved = localStorage.getItem("kharchaData")
    if(saved) {
      setItems(JSON.parse(saved))
    }
  }, [])

  // JAB BHI ITEMS BADLE TO SAVE KAR DO
  useEffect(() => {
    localStorage.setItem("kharchaData", JSON.stringify(items))
  }, [items])

  const total = items.reduce((sum, item) => {
    const num = item.match(/\d+/)
    return sum + (num? parseInt(num[0]) : 0)
  }, 0)

  const handleAdd = () => {
    if(input.trim()!== "") {
      setItems([...items, input])
      setInput("")
    }
  }

  const handleDelete = (index: number) => {
    setItems(items.filter((_, i) => i!== index))
  }

  return (
    <main style={{
      padding: "30px", 
      background: "linear-gradient(135deg, #2196F3 0%, #00BCD4 100%)", 
      minHeight: "100vh",
      fontFamily: "Arial"
    }}>
      <div style={{
        background: "white", 
        padding: "30px", 
        borderRadius: "20px", 
        maxWidth: "500px", 
        margin: "auto",
        boxShadow: "0 15px 50px rgba(0,0,0,0.2)"
      }}>
        
        <h1 style={{textAlign: "center", color: "#2196F3", marginBottom: "20px", fontSize: "26px"}}>🔥 Mera Kharcha</h1>
        
        <div style={{
          background: "linear-gradient(135deg, #2196F3 0%, #1976D2 100%)", 
          color: "white", 
          padding: "25px", 
          borderRadius: "15px", 
          textAlign: "center",
          marginBottom: "20px"
        }}>
          <p style={{margin: 0, fontSize: "14px", opacity: 0.9}}>Total Kharcha</p>
          <h2 style={{margin: "8px 0", fontSize: "40px", fontWeight: "bold"}}>₹{total}</h2>
        </div>

        <div style={{display: "flex", gap: "10px", marginBottom: "20px"}}>
          <input 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleAdd()} // Enter se bhi add
            placeholder="jaise: chai 20"
            style={{
              flex: 1, 
              padding: "14px",
              borderRadius: "10px",
              border: "2px solid #BBDEFB",
              fontSize: "16px",
              outline: "none"
            }}
          />
          <button onClick={handleAdd} style={{
            padding: "14px 30px", 
            background: "#2196F3", 
            color: "white",
            border: "none",
            borderRadius: "10px",
            fontWeight: "bold",
            fontSize: "16px",
            cursor: "pointer"
          }}>
            Add
          </button>
        </div>

        <div>
          {items.length === 0 && <p style={{textAlign: "center", color: "#999", marginTop: "20px"}}>Abhi koi kharcha nahi</p>}
          {items.map((item, i) => (
            <div key={i} style={{
              background: "#E1F5FE", 
              color: "#000000", // KALA MOTTA TEXT
              padding: "14px 16px", 
              borderRadius: "10px",
              marginBottom: "10px",
              fontSize: "16px",
              fontWeight: "700",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center"
            }}>
              <span>- {item}</span>
              <button onClick={() => handleDelete(i)} style={{
                background: "#f44336",
                color: "white",
                border: "none",
                borderRadius: "6px",
                padding: "6px 12px",
                cursor: "pointer",
                fontSize: "14px",
                fontWeight: "bold"
              }}>
                Delete
              </button>
            </div>
          ))}
        </div>

      </div>
    </main>
  )
}